-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost:8889
-- Generation Time: Feb 28, 2017 at 01:28 AM
-- Server version: 5.5.42
-- PHP Version: 5.6.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `spooky_sim`
--
CREATE DATABASE IF NOT EXISTS `spooky_sim` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `spooky_sim`;

-- --------------------------------------------------------

--
-- Table structure for table `archetype`
--

CREATE TABLE `archetype` (
  `name` varchar(255) DEFAULT NULL,
  `brawn` int(11) DEFAULT NULL,
  `brain` int(11) DEFAULT NULL,
  `luck` int(11) DEFAULT NULL,
  `empathy` int(11) DEFAULT NULL,
  `assets` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `campaign`
--

CREATE TABLE `campaign` (
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `story_type` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_archetype`
--

CREATE TABLE `campaign_archetype` (
  `campaign_id` int(11) DEFAULT NULL,
  `archetype_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `campaign_character`
--

CREATE TABLE `campaign_character` (
  `campaign_id` int(11) DEFAULT NULL,
  `character_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `character`
--

CREATE TABLE `character` (
  `name` varchar(255) DEFAULT NULL,
  `brawn` int(11) DEFAULT NULL,
  `brain` int(11) DEFAULT NULL,
  `luck` int(11) DEFAULT NULL,
  `empathy` int(11) DEFAULT NULL,
  `assets` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `scenario`
--

CREATE TABLE `scenario` (
  `name` varchar(255) DEFAULT NULL,
  `description` text,
  `catalyst_name` varchar(255) DEFAULT NULL,
  `catalyst_type` varchar(255) DEFAULT NULL,
  `scope` int(11) DEFAULT NULL,
  `time_frame` int(11) DEFAULT NULL,
  `threat_name` varchar(255) DEFAULT NULL,
  `threat_type` int(11) DEFAULT NULL,
  `story_type` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL,
  `campaign_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `archetype`
--
ALTER TABLE `archetype`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `campaign`
--
ALTER TABLE `campaign`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `character`
--
ALTER TABLE `character`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `scenario`
--
ALTER TABLE `scenario`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `archetype`
--
ALTER TABLE `archetype`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `campaign`
--
ALTER TABLE `campaign`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `character`
--
ALTER TABLE `character`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `scenario`
--
ALTER TABLE `scenario`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
